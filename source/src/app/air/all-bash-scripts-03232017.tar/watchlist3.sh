#!/bin/bash
# This script checks to see if watchlist.raw has been updated within the last 15 minutes, and generates new data if it has.
# Define function
function go {
    pub=~/public_html/
    # Clean up thinkorswim export
    sed -i '1,4d' watchlist.raw
    #sed -i '$ d' watchlist.raw
    # Generate symbol file
    cut -d ',' -f1 watchlist.raw > watchlist.symbols

    # Generate the goods
    cat watchlist.symbols | while read line || [ -n "$line" ]
    do    
        symbol="$(echo $line)"
        # Get price, volume, and percent change for spreadsheet
        historicalData="$(curl -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6" https://api.tradier.com/v1/markets/history?symbol="$symbol" -H "Accept: application/json")"
        data="$(curl -X GET "https://sandbox.tradier.com/v1/markets/quotes?symbols="$symbol"" -H "Accept: application/json" -H "Authorization: Bearer viLNMb4VAokm0fSryV3zwUXIlv0t")"	
        volume="$(echo $historicalData | ./jq-linux64 '.history.day[].volume' $1)"
        volume60=$(echo $volume | tr ' ' '\n' | tail -60)
        averageVolume="$(echo $volume60 | tr ' ' '\n' | awk '{ sum += $1 } END { if (NR > 0) printf("%f", sum / NR) }')"
        company="$(echo $data | ./jq-linux64 '.quotes.quote.description' $1)"
        company="$(echo $company | sed 's/,//')"
        intradayPrice="$(echo $data | ./jq-linux64 '.quotes.quote.last' $1)"
        intradayVolume="$(echo $data | ./jq-linux64 '.quotes.quote.volume' $1)"
        percentChange="$(echo $data | ./jq-linux64 '.quotes.quote.change_percentage' $1)"
        # Get shares short
        shortData="$(curl https://www.quandl.com/api/v3/datasets/SI/"$symbol"_SI.json?api_key=pDqgMz1TxeRQxoExz8VW)"
        short="$(echo $shortData | ./jq-linux64 '.dataset.data[0][1]' $1)"
	
        echo $symbol","$short","$averageVolume","$company","$intradayPrice","$intradayVolume","$percentChange >> watchlist.sort.csv
    done

    # Sort by percent change
     sort -t , -k 7nr watchlist.sort.csv > watchlist.sorted.csv && rm watchlist.sort.csv
    # Remove double quotes
     sed 's/\"//g' watchlist.sorted.csv > watchlist.tmp.csv && mv watchlist.tmp.csv watchlist.sorted.csv
     mv watchlist.sorted.csv watchlist.csv

    # Retain symbol list for download
    cp watchlist.symbols $pub"wp-content/plugins/s2member-files/access-s2member-level1/watchlist-symbols.txt"

    # Generate charts
    # Iterate through each symbol and pull price history
    while read s; do
	wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc"	
	mv $s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc" $s".csv"
	cut --complement -d, -f 3-9,13 $s".csv" > $s"-3mo.csv" && rm $s".csv" && mv $s"-3mo.csv" $pub$s".csv"
	sed -i 1d  $pub$s".csv"
	sed -i '1i Date,Open,High,Low,Close' $pub$s".csv"
    done <watchlist.symbols

    # Iterate through each symbol and build php file
    while read s; do
	sed 's/symbol/'$s'/g' $pub"symbol.php" > $pub$s".php"
    done <watchlist.symbols
}

export -f go
find watchlist.raw -mmin -14 -exec bash -c 'go' {} \;



