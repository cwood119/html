#!/bin/bash
cp ~/tomorrow.csv ~/tomorrow-db.csv
sed -i '1i symbol,sharesshort,averagevolume,name,previouscloseprice,date,expected' ~/tomorrow-db.csv
INPUT=~/tomorrow-db.csv
OLDIFS=$IFS
PGPASSWORD=****************
IFS=','
table='ecal'
cols='"symbol","sharesshort", "averagevolume", "name", "previouscloseprice", "date", "expected"'
DBNAME='mymedi13_ecal'
 
export PGPASSWORD
 
while read symbol sharesshort averagevolume name previouscloseprice date expected
do
  symbol=$symbol
  sharesshort=$sharesshort
  averagevolume=$averagevolume
  name=$name
  previouscloseprice=$previouscloseprice
  date=$date
  expected=`echo $expected | sed 's/\\r//g'`
  export symbol sharesshort averagevolume name previouscloseprice date expected
 
#
  INSERTSQL="insert into $table ($cols) VALUES($symbol,'$sharesshort','$averagevolume','$name','$previouscloseprice','$date','$expected');"
  echo $INSERTSQL
  /usr/bin/psql -p 5432 -U mymedi13_cwood --set ON_ERROR_STOP=on -c "${INSERTSQL}" $DBNAME
done < $INPUT
 
 
IFS=$OLDIF

#rm ~/tomorrow-db.csv