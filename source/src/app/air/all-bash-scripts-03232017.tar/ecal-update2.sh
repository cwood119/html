#!/bin/bash
# Define variables
now=$(date +"%H")
pub=~/public_html/QuoVadimus/

# Generate the goods
cat tomorrow.csv | while read thisLine
do
        # Pull price and symbol from yesterday's calendar list.  Price will be yesterday's EOD price.
        symbol="$(echo $thisLine | cut --complement -d, -f 2-7)"
        # Get price, volume, and percent change for spreadsheet
	data="$(curl -X GET "https://api.tradier.com/v1/markets/quotes?symbols="$symbol"" -H "Accept: application/json" -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6")"	
    	intradayPrice="$(echo $data | ./jq-linux64 '.quotes.quote.last' $1)"
        intradayVolume="$(echo $data | ./jq-linux64 '.quotes.quote.volume' $1)"
        percentChange="$(echo $data | ./jq-linux64 '.quotes.quote.change_percentage' $1)"
	# Build calendar update spreadsheet by sending each line of yesterday's calendar list, intraday volume, and percent change to csv file
        echo $thisLine","$intradayPrice","$intradayVolume","$percentChange >> ecal.update.sort.csv
done

# Sort by percent change
sort -t , -k 10nr ecal.update.sort.csv > ecal.update.sorted.csv && rm ecal.update.sort.csv
	
mv ecal.update.sorted.csv ecal-update.csv