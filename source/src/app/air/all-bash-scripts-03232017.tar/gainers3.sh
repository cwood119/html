#!/bin/bash

# External programs that are needed for this script to execute properly: jq-linux64, xml2json
# wget https://github.com/stedolan/jq/releases/download/jq-1.5/jq-linux64 &&
# chmod +x jq-linux64
# git clone https://github.com/hay/xml2json.git
# chmod +x xml2json

# Define Variables
tomorrow=$(date --date="next day" "+%Y%m%d")
pub=~/public_html/QuoVadimus/
mon=`date +%m`
now=$(date +"%H")

# Remove Symbols above $20 and under $1
sed -i '1i Symbol,Price' "EOD.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Price"] < 20' "EOD.csv" > "EOD1.csv"
sed -i '1i Symbol,Price' "EOD1.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Price"] > 1' "EOD1.csv" > "EOD.csv"
rm EOD1.csv

# Get all symbols that don't contain _
cat EOD.csv | egrep -v '_' > EOD1.csv
# Isolate symbols
cut --complement -d, -f 2 EOD1.csv > symbols-gainers
# Preserve master symbol list
cp symbols-gainers symbols-gainers-dynamic
cp EOD1.csv EOD1-dynamic

# Define function
function eighty {
    # Pull first 100 symbols 
    scount=$(wc -l< symbols-gainers-dynamic)
    if [[ $scount -lt 100 ]]; then
        sed -n -e '1,'$scount'p' symbols-gainers-dynamic >>  symbols-gainers-reader
    else
        sed -n -e '1,100p' symbols-gainers-dynamic >>  symbols-gainers-reader
    fi
	# Read the file and put all symbols on one line for api call
	list=	
	cat symbols-gainers-reader | while read line
	do   
	    list=$list$line","
	    echo $list > symbols-gainers.csv
	done	
	rm symbols-gainers-reader
	# Remove first 100 symbols from dynamic file
	sed '1,100d' symbols-gainers-dynamic >> symbols-gainers-dynamic-tmp && mv symbols-gainers-dynamic-tmp symbols-gainers-dynamic
	# Remove last , in the line
	sed -i '$ s/.$//' symbols-gainers.csv
	# Get intraday data json
	list=$(cat symbols-gainers.csv)	
#	intradayPriceVolume="$(curl http://finance.yahoo.com/webservice/v1/symbols/"$list"/quote?format=json)"
        intradayPriceVolume="$(curl -X GET "https://api.tradier.com/v1/markets/quotes?symbols="$list"" -H "Accept: application/json" -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6")"
	echo $intradayPriceVolume >> intradayPriceVolume.json
	# Pull first 100 symbols from EOD1
        scount=$(wc -l< EOD1.csv)
    if [[ $scount -lt 100 ]]; then
        sed -n -e '1,'$scount'p' EOD1-dynamic >>  EOD1-reader
        echo $scount" is less than 100"
    else
        sed -n -e '1,100p' EOD1-dynamic >>  EOD1-reader
    fi
	# Remove first 100 symbols from dynamic file
    sed '1,100d' EOD1-dynamic >> EOD1-dynamic-tmp && mv EOD1-dynamic-tmp EOD1-dynamic
	jsonIndex=1 
	count=$(wc -l< EOD1-reader)
	for (( i = 1; i <= count; ++i )) {
		line=
		price=
		symbol=
		intradayPrice=
		intradayVolume=
		sed -n $jsonIndex"p" EOD1-reader > line
                line=$(cat line)
                jsonIndex=$(($jsonIndex-1))
		# Pull price and symbol from master symbol list.  Price will be yesterday's EOD price.
                price=$(./jq-linux64 '.quotes.quote['$jsonIndex'].prevclose' intradayPriceVolume.json)
                symbol=$(./jq-linux64 '.quotes.quote['$jsonIndex'].symbol' intradayPriceVolume.json)
		# Get intraday price
	        intradayPrice=$(./jq-linux64 '.quotes.quote['$jsonIndex'].last' intradayPriceVolume.json)
		#intradayPrice=$(echo $intradayPrice | sed -e 's/^"//'  -e 's/"$//')
		# Calculate percent change
        	#subtract=$(echo $intradayPrice - $price | bc)
        	#percentCalc=$(echo $subtract / $price | bc -l)
        	#percentChange=$(echo $percentCalc \* 100 | bc -l)
                percentChange=$(./jq-linux64 '.quotes.quote['$jsonIndex'].change_percentage' intradayPriceVolume.json)
        	# Get intraday volume
        	intradayVolume=$(./jq-linux64 '.quotes.quote['$jsonIndex'].volume' intradayPriceVolume.json)
        	# Build csv spreadsheet
        	echo $symbol","$price","$intradayPrice","$intradayVolume","$percentChange >> $pub"sort.csv"
		jsonIndex=$(($jsonIndex + 2))
	}
	# Clean up
	rm EOD1-reader && rm symbols-gainers.csv && rm line && rm intradayPriceVolume.json
}
# Check if dynamic file is empty.  If not, perform eighty function
while test -s "symbols-gainers-dynamic"
do
    eighty
done
# Clean up
cat symbols-gainers
rm EOD1.csv  && rm EOD1-dynamic && rm symbols-gainers-dynamic && rm symbols-gainers 
# Remove double quotes
sed 's/\"//g' $pub"sort.csv"> $pub"tmp.csv" && mv $pub"tmp.csv" $pub"sort.csv"
# Sort by Percent Change
sort -t , -k 10nr $pub"sort.csv" > $pub"sorted.csv"
rm $pub"sort.csv"
# Remove Symbols above $20 and under $1
sed -i '1i Symbol,Price,IntradayPrice,Volume,PercentChange' $pub"sorted.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["IntradayPrice"] < 20' $pub"sorted.csv" > $pub"filterOne.csv"
sed -i '1i Symbol,Price,IntradayPrice,Volume,PercentChange' $pub"filterOne.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["IntradayPrice"] > 1' $pub"filterOne.csv" > $pub"filterPrice.csv"

# Remove Symbols under 5%
sed -i '1i Symbol,Price,IntradayPrice,Volume,PercentChange' $pub"filterPrice.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["PercentChange"] > 4.99' $pub"filterPrice.csv" > $pub"filterPercent.csv"

# Remove Symbols under 250k Volume
sed -i '1i Symbol,Price,IntradayPrice,Volume,PercentChange' $pub"filterPercent.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Volume"] > 250000' $pub"filterPercent.csv" > $pub"filterVolume.csv"

# Headlines
if test -f "gainers.csv"; then rm "gainers.csv";fi
cat $pub"filterVolume.csv" | while read line
do
 	# Get symbol
	symbol="$(echo $line | cut --complement -d, -f 2-5)"
	# Get headlines
	wget "http://finance.yahoo.com/rss/headline?s="$symbol
	mv "headline?s="$symbol $symbol".xml"
	# Convert xml to json
	python xml2json/xml2json.py -t xml2json -o $symbol".json" $symbol".xml" && rm $symbol".xml"
	# Iterate through titles, search for keywords
	success=0
	pass=0
    for (( i = 0; i <= 19; ++i )) {
        title=$(./jq-linux64 '.rss.channel.item['$i'].title' $symbol".json")
        keywords=("earning" "Earning" "Guidance" "guidance" "Revenue" "revenue" "Financial" "financial" "Fiscal Year-End Results" "10Q" "Third Quarter" "Second Quarter" "First Quarter" "Fourth Quarter" "profit forecasts" "10-Q" "Quarterly Report")
        for ((j = 0; j < ${#keywords[@]}; j++))
        do
            if [[ $title  == *"${keywords[$j]}"* ]] && [[ $title != *"8-K"* ]] ; then
                success=1
            fi
        done
        # If title contains keyword, check date for relevance (within 20 days)  
        if [[ $success -eq 1 ]] ; then
            pubDate=$(./jq-linux64 '.rss.channel.item['$i'].pubDate' $symbol".json")
            thisYear=$(date +%Y)
            thisMonth=$(date +%b)
            thisDay=$(date +%d)
            thisDay=$((10#$thisDay))
            lastMonth=$(date --date="$(date +%Y-%m-15) -1 month" +'%b')
            titleDay=$(echo ${pubDate:6:2})
            titleDay=$((10#$titleDay))
            titleMonth=$(echo ${pubDate:8:4})
            titleYear=$(echo ${pubDate:13:4})
            difference=$((thisDay-titleDay))
            (($((10#$difference)) <= -11)) && lastDifference=1 || lastDifference=0
            if [[ $thisMonth == $titleMonth && $thisYear == $titleYear || $lastMonth == $titleMonth && $thisYear == $titleYear ]] ; then
                # If headline date is from last month AND it's within a reasonable number days  
                if [[ $lastMonth == $titleMonth  &&  $lastDifference -eq 1 ]] ; then
                    pass=1
                fi
                # If headline date is from this month AND it's within 10 days
                if [[ $thisMonth == $titleMonth && $((10#$difference)) < 10 ]] ; then
                    pass=1
                fi
            fi
        fi
    }
    if [[ $pass -eq 1 ]] ; then
        echo $line >> gainers.csv
    fi
done
# Clean up
rm $pub"filterOne.csv" && rm $pub"filterPercent.csv" && rm $pub"filterPrice.csv" && rm $pub"filterVolume.csv" && rm $pub"sorted.csv" && rm *.json

# Get company name
wget http://www.quandl.com/api/v3/databases/EOD/codes
mv codes codes.zip && unzip codes.zip
cut -c5- EOD-datasets-codes.csv > removeEOD.csv
sed 's/\"//g' removeEOD.csv > removeQuotes.csv
sed 's/(.*//' removeQuotes.csv > names.csv
sort -t , -k 1,1 names.csv > names-sorted.csv
sort -t, -k 1,1 gainers.csv > gainers-sorted.csv
join -t , -1 1 -2 1 names-sorted.csv gainers-sorted.csv > $pub"combined.csv"
rm remove*.csv && rm names.csv && rm names-sorted.csv && rm gainers-sorted.csv && rm EOD-datasets-codes.csv && rm gainers.csv

# Get average volume
cut --complement -d, -f 2-6 $pub"combined.csv" > symbols-gainers
while read s; do
    wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?rows=90&order=desc&column_index=5&api_key=pDqgMz1TxeRQxoExz8VW"
    mv $s".csv?rows=90&order=desc&column_index=5&api_key=pDqgMz1TxeRQxoExz8VW" $s
    cut --complement -d, -f 1 $s > $s"vol" && rm $s && mv $s"vol" $s
    while read; do
        avg=$(awk '{ sum += $1 } END { if (NR > 0) printf("%f", sum / NR) }')
    done <$s
    echo $s","$avg >>  $pub"adv.csv"
    rm $s
done <symbols-gainers

# Combine average volume with the rest of the data
join -t , -1 1 -2 1 $pub"adv.csv" $pub"combined.csv" > $pub"volCombined.csv"

# Get shares short
cut --complement -d, -f 2-7 $pub"volCombined.csv" > symbols-gainers
while read s; do
    wget "https://www.quandl.com/api/v1/datasets/SI/"$s"_SI.csv?api_key=pDqgMz1TxeRQxoExz8VW"
    mv $s"_SI.csv?api_key=pDqgMz1TxeRQxoExz8VW" $s
    cut --complement -d, -f 1,3,4 $s > $s"short" && rm $s && mv $s"short" $s
    sed -i 1d $s
    short=$(head -1 $s)
    echo $s","$short >>  $pub"short.csv"
    rm $s
    if test -f $s"short"; then rm $s"short";fi
done <symbols-gainers

# Combine shares short with the rest of the data into gainers.csv
if test -f $pub"gainers.csv"; then rm $pub"gainers.csv";fi
join -t , -1 1 -2 1 $pub"short.csv" $pub"volCombined.csv" > $pub"gainers.csv"

# Sort by percent change
sort -t , -k 8,8nr $pub"gainers.csv" > gainers.csv

# Clean up
rm $pub"adv.csv" && rm $pub"combined.csv" && rm $pub"short.csv" && rm $pub"volCombined.csv" && rm $pub"gainers.csv"

# Finalize mid morning list
if [ "$now" -eq 9 ] || [ "$now" -eq 10 ]
then
	# Generate file to be read by the front end
	mv gainers.csv mid-morning-percent-gainers.csv
	 
	# Generate symbol file for charts
	cut -d ',' -f1 mid-morning-percent-gainers.csv > mid-morning-percent-gainers-symbols
	 
	# Generate charts
	pub=~/public_html/
	# Iterate through each symbol and pull price history
	while read s; do
		wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc"	
		mv $s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc" $s".csv"
		cut --complement -d, -f 3-9,13 $s".csv" > $s"-3mo.csv" && rm $s".csv" && mv $s"-3mo.csv" $pub$s".csv"
		sed -i 1d  $pub$s".csv"
		sed -i '1i Date,Open,High,Low,Close' $pub$s".csv"
	done <mid-morning-percent-gainers-symbols
        
	# Iterate through each symbol and build php file
	while read s; do
		sed 's/symbol/'$s'/g' $pub"symbol.php" > $pub$s".php"
	done <mid-morning-percent-gainers-symbols
fi

# Finalize mid day list
if [ "$now" -eq 11 ] || [ "$now" -eq 12 ]
then
	# Generate file to be read by the front end
        mv gainers.csv mid-day-percent-gainers.csv
        
        # Generate symbol file for charts
	cut -d ',' -f1 mid-day-percent-gainers.csv > mid-day-percent-gainers-symbols
	 
	# Generate charts
	pub=~/public_html/
	# Iterate through each symbol and pull price history
	while read s; do
		wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc"	
		mv $s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc" $s".csv"
		cut --complement -d, -f 3-9,13 $s".csv" > $s"-3mo.csv" && rm $s".csv" && mv $s"-3mo.csv" $pub$s".csv"
		sed -i 1d  $pub$s".csv"
		sed -i '1i Date,Open,High,Low,Close' $pub$s".csv"
	done <mid-day-percent-gainers-symbols
        
	# Iterate through each symbol and build php file
	while read s; do
		sed 's/symbol/'$s'/g' $pub"symbol.php" > $pub$s".php"
	done <mid-day-percent-gainers-symbols
fi

# Finalize power hour list
if [ "$now" -eq 13 ] || [ "$now" -eq 14 ]
then
	# Generate file to be read by the front end
        mv gainers.csv power-hour-percent-gainers.csv
        
        # Generate symbol file for charts
	cut -d ',' -f1 power-hour-percent-gainers.csv > power-hour-percent-gainers-symbols
	 
	# Generate charts
	pub=~/public_html/
	# Iterate through each symbol and pull price history
	while read s; do
		wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc"	
		mv $s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc" $s".csv"
		cut --complement -d, -f 3-9,13 $s".csv" > $s"-3mo.csv" && rm $s".csv" && mv $s"-3mo.csv" $pub$s".csv"
		sed -i 1d  $pub$s".csv"
		sed -i '1i Date,Open,High,Low,Close' $pub$s".csv"
	done <power-hour-percent-gainers-symbols
        
	# Iterate through each symbol and build php file
	while read s; do
		sed 's/symbol/'$s'/g' $pub"symbol.php" > $pub$s".php"
	done <power-hour-percent-gainers-symbols
fi

# Clean up
jsonFiles=*.json
if ls $jsonFiles 1> /dev/null 2>&1; then rm $jsonFiles;fi