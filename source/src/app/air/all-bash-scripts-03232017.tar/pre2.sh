#!/bin/bash

# Define Variables
tomorrow=$(date --date="next day" "+%Y%m%d")
today=`date +%Y-%m-%d`
pub=~/public_html/QuoVadimus/

# Copy from previous night's calendar
cp tomorrow.csv pre.csv 

# Remove symbols that don't announce pre market
sed -i '1i one,two,three,four,five,six,seven' "pre.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["seven"] < 3' "pre.csv" > "pre1.csv"
rm pre.csv && mv pre1.csv pre.csv
sed -i '1i one,two,three,four,five,six,seven' "pre.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["seven"] > 1' "pre.csv" > "pre1.csv"
rm pre.csv && mv pre1.csv pre.csv

# Iterate through symbols and request pre market price
cat pre.csv | while read line || [ -n "$line" ]
do
    # Get symbol
    symbol="$(echo $line | cut --complement -d, -f 2-7)"
    # Get quote for symbol 
    data=$(curl -X GET "https://api.tradier.com/v1/markets/quotes?symbols="$symbol -H "Accept: application/json" -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6")
    # Get price
    price=$(echo $data | ./jq-linux64 '.quotes.quote.last' $1)
    # Get pre market time and sales data    
    preData="$(curl -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6" -H "Accept: application/json" "https://api.tradier.com/v1/markets/timesales?symbol=$symbol")"
    # Get pre market price 
    prePrice=$(echo $preData | ./jq-linux64 '.series.data[].price | length' $1 | tail -1)
    preTimestamp=$(echo $preData | ./jq-linux64 '.series.data[].timestamp | length' $1 | tail -1)
    if [[ $preTimestamp -gt 1469822400 ]] ; then
        # Calculate percent change
        subtract=$(echo $prePrice - $price | bc)
        percentCalc=$(echo $subtract / $price | bc -l)
        percentChange=$(echo $percentCalc \* 100 | bc -l) 
        echo $line","$prePrice","$percentChange >> preSort.csv
    fi
done

# Sort by percent changepre
sort -t , -k 9nr preSort.csv > preSorted.csv && rm preSort.csv

mv preSorted.csv pre.csv