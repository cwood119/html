#!/bin/bash
# Define variables
path=~/public_html/wp-content/plugins/s2member-files/access-s2member-level1/Charts

ls $path"/Day_1/Breakouts/" > tmp.csv && awk '{print $0",1,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Breakouts/"$0"&s2member_skip_confirmation"}' tmp.csv > deCharts.csv

ls $path"/Day_1/Dip/" > tmp.csv && awk '{print $0",1,2,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Dip/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Day_1/Morning_Spike/" > tmp.csv && awk '{print $0",1,3,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Morning_Spike/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Day_2/Breakouts/" > tmp.csv && awk '{print $0",2,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_2/Breakouts/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Day_2/Dips/" > tmp.csv && awk '{print $0",2,2,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_2/Dips/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Day_2/Red_to_Green/" > tmp.csv && awk '{print $0",2,3,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_2/Red_to_Green/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Days_3_10/Breakouts/" > tmp.csv && awk '{print $0",3,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Days_3_10/Breakouts/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Days_3_10/Dips/" > tmp.csv && awk '{print $0",3,2,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Days_3_10/Dips/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/PEAD/" > tmp.csv && awk '{print $0",4,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/PEAD/"$0"&s2member_skip_confirmation"}' tmp.csv >> deCharts.csv

ls $path"/Channels/" > tmp.csv && awk '{print $0",5,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Channels/"$0}' tmp.csv >> deCharts.csv
rm tmp.csv