#!/bin/bash

# External programs that are needed for this script to execute properly: jq-linux64, xml2json
# wget https://github.com/stedolan/jq/releases/download/jq-1.5/jq-linux64 &&
# chmod +x jq-linux64
# git clone https://github.com/hay/xml2json.git
# chmod +x xml2json

# Define Variables
pub=~/public_html/
gainersPath=~/public_html/app/app/air/market-movers/data/
gainersDevPath=~/public_html/dev/app/air/market-movers/data/
dePath=~/public_html/app/app/air/decision-engine/data/
tradierApi=2IigxmuJp1Vzdq6nJKjxXwoXY9D6

# Make temporary directory
if [ -d ~/extended/ ]; then rm -rf ~/extended; fi
mkdir ~/extended
ls | grep symbol-.*.php | while read file; do cp $file ~/extended/; done
cp jq-linux64 ~/extended/ && cp -r xml2json ~/extended/ && cd ~/extended

# Get symbols
curl -u "506540ef71e2788714ac2bdd2255d337:1d3bce294c77797adefb8a602339ff21" "https://api.intrinio.com/securities/search?page_number=1&page_size=500&conditions=open_price~lt~15,open_price~gt~1" > gainers-symbols.json
./jq-linux64 '.data[].ticker' gainers-symbols.json > gainers-symbols
pages=$(./jq-linux64 '.total_pages' gainers-symbols.json)
for (( i = 2; i <= pages; ++i )) {
    curl -u "506540ef71e2788714ac2bdd2255d337:1d3bce294c77797adefb8a602339ff21" "https://api.intrinio.com/securities/search?page_number=$i&page_size=500&conditions=open_price~lt~15,open_price~gt~1" > gainers-symbols.json
    ./jq-linux64 '.data[].ticker' gainers-symbols.json >> gainers-symbols
}
sed -i 's/\"//g' gainers-symbols

# Remove duplicates
sort -u gainers-symbols > gainers-unique && mv gainers-unique gainers-symbols
rm gainers-symbols.json
cp gainers-symbols gainers-symbols-dynamic && cp gainers-symbols gainers-dynamic

function bulkQuotes {
    # Pull first 100 symbols and place them in a temporary reader file
    scount=$(wc -l< gainers-symbols-dynamic)
    if [[ $scount -lt 100 ]]; then
        sed -n -e '1,'$scount'p' gainers-symbols-dynamic >>  gainers-symbols-reader
    else
        sed -n -e '1,100p' gainers-symbols-dynamic >>  gainers-symbols-reader
    fi
    # Read the reader file and put all symbols on one line for bulk api call
    list=
    cat gainers-symbols-reader | while read line
    do
        list=$list$line","
        echo $list > gainers-symbols-list
    done
    # Remove first 100 symbols from dynamic file
    sed '1,100d' gainers-symbols-dynamic >> gainers-symbols-dynamic-tmp && mv gainers-symbols-dynamic-tmp gainers-symbols-dynamic
    # Remove last , in the line
    sed -i '$ s/.$//' gainers-symbols-list

    rm gainers-symbols-reader
    # Generate the goods
    list=$(cat gainers-symbols-list)

    # Get quote data
echo "vvv Getting quote data vvv"
    data="$(curl -X GET "https://api.tradier.com/v1/markets/quotes?symbols="$list"" -H "Accept: application/json" -H "Authorization: Bearer "$tradierApi"")"
    echo $data > gainers-data.json

    # Get share data
echo "vvv Getting fundamentals data vvv"
    tradierCompanyApi="$(curl -X GET "https://api.tradier.com/beta/markets/fundamentals/company?symbols="$list"" -H "Accept: application/json" -H "Authorization: Bearer "$tradierApi"")"
    echo $tradierCompanyApi > gainers-fundamentals.json
    # Pull first 100 symbols and place them in a temporary reader file
    scount=$(wc -l< gainers-dynamic)
    if [[ $scount -lt 100 ]]; then
        sed -n -e '1,'$scount'p' gainers-dynamic >>  gainers-reader
    else
        sed -n -e '1,100p' gainers-dynamic >>  gainers-reader
    fi
# Remove first 100 symbols from dynamic file
    sed '1,100d' gainers-dynamic >> gainers-dynamic-tmp && mv gainers-dynamic-tmp gainers-dynamic

    jsonIndex=1
    count=$(wc -l< gainers-reader)
        for (( i = 1; i <= count; ++i )) {
            line=
            sed -n $jsonIndex"p" gainers-reader > line
            line=$(cat line)
            jsonIndex=$(($jsonIndex-1))
            # Get price and remove any symbols over $20
            price=$(./jq-linux64 '.quotes.quote['$jsonIndex'].last' gainers-data.json)
            prevclose=$(./jq-linux64 '.quotes.quote['$jsonIndex'].prevclose' gainers-data.json)

            if (( $(echo "$price > 20" | bc -l) )) ; then
                jsonIndex=$(($jsonIndex + 2))
                continue
            else
                bid=$(./jq-linux64 '.quotes.quote['$jsonIndex'].bid' gainers-data.json)
                bid=$(echo $bid | sed -e 's/^"//'  -e 's/"$//')
                if (( $(echo "$bid <= $prevclose" | bc -l) )) ; then
                    jsonIndex=$(($jsonIndex + 2))
                    continue
                else
                    # Calculate percent change
                    subtract=$(echo $bid - $prevclose | bc)
                    percentCalc=$(echo $subtract / $prevclose | bc -l)
                    changePercent=$(echo $percentCalc \* 100 | bc -l)
                    if (( $(echo "$changePercent < 2" | bc -l) )) ; then
                        jsonIndex=$(($jsonIndex + 2))
                        continue
                    else
                        symbol=$(./jq-linux64 '.quotes.quote['$jsonIndex'].symbol' gainers-data.json | sed 's/\"//g')
                        if [ "$symbol" != "null" ]; then echo $symbol >> market.movers.csv;fi
                        jsonIndex=$(($jsonIndex + 2))
                    fi
                fi
            fi

        }

    # Clean up
    rm line && rm gainers-reader && rm gainers-symbols-list && rm gainers-fundamentals.json
}
# Check if dynamic symbol file is empty.  If not, perform bulkQuotes function
while test -s "gainers-symbols-dynamic"
do
    bulkQuotes
done

# Clean up
rm gainers-data.json && rm gainers-symbols-dynamic && rm gainers-dynamic
wc -l market.movers.csv
# Remove double quotes
sed -i 's/\"//g' market.movers.csv
# Headlines
if test -f "gainers.csv"; then rm "gainers.csv";fi
echo "symbol,headline date, 20 days ago, headline" > titles.txt
cat market.movers.csv | while read line
do
    # Get symbol
    symbol=$(echo $line)
    # Get headlines
    wget "http://finance.yahoo.com/rss/headline?s="$symbol
    mv "headline?s="$symbol $symbol".xml"
    # Convert xml to json
    python xml2json/xml2json.py -t xml2json -o $symbol".json" $symbol".xml" && rm $symbol".xml"
    # Iterate through titles, search for keywords
    success=0
    pass=0
    for (( i = 0; i <= 19; ++i )) {
        title=$(./jq-linux64 '.rss.channel.item['$i'].title' $symbol".json")
        keywords=("Earnings Release" "Financial Results" "4Q profit" "4Q loss" "3Q profit" "3Q loss" "2Q profit" "2Q loss" "1Q profit" "1Q loss"  "Quarterly Report" "Earnings Analysis" "Edited Transcript" "Earnings Call Transcript" "profit forecasts" "Earnings Growth" "Earnings Estimates" "Revenue Beat" "Beats on Revenue" "Beats on Revs" "EPS Beat" "Reports Fiscal Year" "Fiscal Year-End Results" "Announces FY 2016 Annual Results" "Announces FY 2017 Annual Results" "10Q" "Increases Guidance" "Increased Guidance" "Raises Guidance" "Raised Guidance"  "Reports Q4 EPS" "Reports Q3 EPS" "Reports Q2 EPS" "Reports Q1 EPS" "Q4 EPS" "Q3 EPS" "Q2 EPS" "Q1 EPS" "FY16 Results Improve Vs" "FY17 Results Improve Vs" "Sales Increase By" "Net Income up by" "Raises FYQ1 Outlook" "Raises FYQ2 Outlook" "Raises FYQ3 Outlook" "Raises FYQ4 Outlook" "Q1 revs at high-end of guidance" "Q2 revs at high-end of guidance" "Q3 revs at high-end of guidance" "Q4 revs at high-end of guidance" "reports smaller quarterly loss" "Profit at the high end of prior range" "Revenues Top")

        success=0
        for ((j = 0; j < ${#keywords[@]}; j++))
        do
            if [[ $title  == *"${keywords[$j]}"* ]] && [[ $title != *"Conference Call Date"* ]] && [[ $title != *"8-K"* ]] && [[ $title != *"NDA Submission"* ]]; then
                success=1
            fi
        done
        # If title contains keyword, check date for relevance 
        if [[ $success -eq 1 ]] ; then
            pubDate=$(./jq-linux64 '.rss.channel.item['$i'].pubDate' $symbol".json")
            titleDay=$(echo ${pubDate:6:2})
            titleDay=$((10#$titleDay))
            titleMonth=$(echo ${pubDate:8:4})
            titleYear=$(echo ${pubDate:13:4})
            yesterday=$(date -d "yesterday" "+%Y%m%d")
            titleDate=$(date -d "$titleDay $titleMonth $titleYear" +%Y%m%d)
            # If headline date is from yesterday or pre market 
            if (( $titleDate >= $yesterday )); then
                pass=1
                echo $symbol,$titleDate,$yesterday,$title >> titles.txt
            fi
        fi
    }
    if [[ $pass -eq 1 ]] ; then
        echo $line >> gainers.csv
    fi
    rm $symbol".json"
done
mv market.movers.csv before-headlines-filter.csv && rm gainers-symbols
cp gainers.csv after-headlines-filter.csv
# Get data for final list
touch gainers-symbols-dynamic
if test -f "gainers.csv"; then cp gainers.csv gainers-symbols-dynamic && mv gainers.csv gainers-dynamic; fi

function getQuotes {
    # Pull first 100 symbols and place them in a temporary reader file
    scount=$(wc -l< gainers-symbols-dynamic)
    if [[ $scount -lt 100 ]]; then
        sed -n -e '1,'$scount'p' gainers-symbols-dynamic >>  gainers-symbols-reader
    else
        sed -n -e '1,100p' gainers-symbols-dynamic >>  gainers-symbols-reader
    fi
    # Read the reader file and put all symbols on one line for bulk api call
    list=
    cat gainers-symbols-reader | while read line
    do
        list=$list$line","
        echo $list > gainers-symbols-list
    done
    # Remove first 100 symbols from dynamic file
    sed '1,100d' gainers-symbols-dynamic >> gainers-symbols-dynamic-tmp && mv gainers-symbols-dynamic-tmp gainers-symbols-dynamic
    # Remove last , in the line
    sed -i '$ s/.$//' gainers-symbols-list

    rm gainers-symbols-reader
    # Generate the goods
    list=$(cat gainers-symbols-list)

    # Get quote data
echo "vvv Getting final quote data vvv"
    data="$(curl -X GET "https://api.tradier.com/v1/markets/quotes?symbols="$list"" -H "Accept: application/json" -H "Authorization: Bearer "$tradierApi"")"
    echo $data > gainers-data.json

    # Get share data
echo "vvv Getting final fundamentals data vvv"
    tradierCompanyApi="$(curl -X GET "https://api.tradier.com/beta/markets/fundamentals/company?symbols="$list"" -H "Accept: application/json" -H "Authorization: Bearer "$tradierApi"")"
    echo $tradierCompanyApi > gainers-fundamentals.json

    # Pull first 100 symbols and place them in a temporary reader file
    scount=$(wc -l< gainers-dynamic)
    if [[ $scount -lt 100 ]]; then
        sed -n -e '1,'$scount'p' gainers-dynamic >>  gainers-reader
    else
        sed -n -e '1,100p' gainers-dynamic >>  gainers-reader
    fi
# Remove first 100 symbols from dynamic file
    sed '1,100d' gainers-dynamic >> gainers-dynamic-tmp && mv gainers-dynamic-tmp gainers-dynamic

    jsonIndex=1
    count=$(wc -l< gainers-reader)
        for (( i = 1; i <= count; ++i )) {
            line=
            sed -n $jsonIndex"p" gainers-reader > line
            line=$(cat line)
            jsonIndex=$(($jsonIndex-1))
            if (( $count == 1 )); then 
                price=$(./jq-linux64 '.quotes.quote.last' gainers-data.json)
                changePercent="$(./jq-linux64 '.quotes.quote.change_percentage' gainers-data.json)"
                vol="$(./jq-linux64 '.quotes.quote.volume' gainers-data.json)"
                symbol=$(./jq-linux64 '.quotes.quote.symbol' gainers-data.json | sed 's/\"//g')
            else 
                price=$(./jq-linux64 '.quotes.quote['$jsonIndex'].last' gainers-data.json)
                changePercent="$(./jq-linux64 '.quotes.quote['$jsonIndex'].change_percentage' gainers-data.json)"
                vol="$(./jq-linux64 '.quotes.quote['$jsonIndex'].volume' gainers-data.json)"
                symbol=$(./jq-linux64 '.quotes.quote['$jsonIndex'].symbol' gainers-data.json | sed 's/\"//g')
            fi
            if [ "$symbol" = "" ]; then
                jsonIndex=$(($jsonIndex + 2))
                continue
            fi
            # Calculate average volume 
echo "vvv Getting historical data for "$symbol" vvv"
            historicalData="$(curl -H "Authorization: Bearer "$tradierApi"" https://api.tradier.com/v1/markets/history?symbol="$symbol" -H "Accept: application/json")"
            historicalDataCheck=$(echo $historicalData | ./jq-linux64 '.history' $1)
            if [ "$historicalDataCheck" = "null" ]; then
                jsonIndex=$(($jsonIndex + 2))
                continue
            fi
            volume="$(echo $historicalData | ./jq-linux64 '.history.day[].volume' $1)"
            volume60=$(echo $volume | tr ' ' '\n' | tail -60)
            averageVolume="$(echo $volume60 | tr ' ' '\n' | awk '{ sum += $1 } END { if (NR > 0) printf("%f", sum / NR) }')"
            # Assign quotes data from gainers-data.json file
            if (( $count == 1 )); then 
                company="$(./jq-linux64 '.quotes.quote.description' gainers-data.json)"
                company="$(echo $company | sed 's/,//')"
                change="$(./jq-linux64 '.quotes.quote.change' gainers-data.json)"
                open="$(./jq-linux64 '.quotes.quote.open' gainers-data.json)"
                high="$(./jq-linux64 '.quotes.quote.high' gainers-data.json)"
                low="$(./jq-linux64 '.quotes.quote.low' gainers-data.json)"
                marketCap="$(./jq-linux64 '.[].results[1].tables.share_class_profile.market_cap' gainers-fundamentals.json)"
                sharesOutstanding="$(./jq-linux64 '.[].results[1].tables.share_class_profile.shares_outstanding' gainers-fundamentals.json)"
                insiderOwnership="$(./jq-linux64 '.[].results[1].tables.ownership_summary.insider_shares_owned' gainers-fundamentals.json)"
            else
                company="$(./jq-linux64 '.quotes.quote['$jsonIndex'].description' gainers-data.json)"
                company="$(echo $company | sed 's/,//')"
                change="$(./jq-linux64 '.quotes.quote['$jsonIndex'].change' gainers-data.json)"
                open="$(./jq-linux64 '.quotes.quote['$jsonIndex'].open' gainers-data.json)"
                high="$(./jq-linux64 '.quotes.quote['$jsonIndex'].high' gainers-data.json)"
                low="$(./jq-linux64 '.quotes.quote['$jsonIndex'].low' gainers-data.json)"
                marketCap="$(./jq-linux64 '.['$jsonIndex'].results[1].tables.share_class_profile.market_cap' gainers-fundamentals.json)"
                sharesOutstanding="$(./jq-linux64 '.['$jsonIndex'].results[1].tables.share_class_profile.shares_outstanding' gainers-fundamentals.json)"
                insiderOwnership="$(./jq-linux64 '.['$jsonIndex'].results[1].tables.ownership_summary.insider_shares_owned' gainers-fundamentals.json)"
            fi
            shortData="$(curl https://www.quandl.com/api/v3/datasets/SI/"$symbol"_SI.json?api_key=pDqgMz1TxeRQxoExz8VW)"
            short="$(echo $shortData | ./jq-linux64 '.dataset.data[0][1]' $1)"
            float=$((sharesOutstanding-insiderOwnership))
            shortPercent=$(echo $short / $float | bc -l)
            shortPercent=$(echo $shortPercent \* 100 | bc -l | awk '{printf "%f", $0}')

            # Build csv spreadsheet
            if [ "$symbol" != "" ]; then
                echo $symbol","$short","$averageVolume","$company","$price","$change","$changePercent","$open","$high","$low","$vol","$marketCap","$sharesOutstanding","$insiderOwnership","$shortPercent","$float >> market.movers.csv
            fi
            jsonIndex=$(($jsonIndex + 2))
        }

    # Clean up
    rm line && rm gainers-reader && rm gainers-symbols-list && rm gainers-fundamentals.json
}
# Check if dynamic symbol file is empty.  If not, perform getQuotes function
while test -s "gainers-symbols-dynamic"
do
    getQuotes
done

# Clean up
#rm gainers-data.json && rm gainers-symbols-dynamic && rm gainers-dynamic

# Remove double quotes
if test -f market.movers.csv; then sed -i 's/\"//g' market.movers.csv;fi

# Pull headlines and other vitals, then convert to JSON
echo '[' > data.json
touch symbols.txt
id=1

function finalQuotes {
cat market.movers.csv | while read line || [ -n "$line" ]
do
    # Define variables for symbol card and vitals
    symbol="$(echo $line | cut -d, -f 1)"
    sharesShort="$(echo $line | cut -d, -f 2)"
    avgVol="$(echo $line | cut -d, -f 3)"
    name="$(echo $line | cut -d, -f 4)"
    name="$(echo $name | cut -c1-20)"
    price="$(echo $line | cut -d, -f 5)"
    change="$(echo $line | cut -d, -f 6)"
    changePercent="$(echo $line | cut -d, -f 7)"
    open="$(echo $line | cut -d, -f 8)"
    high="$(echo $line | cut -d, -f 9)"
    low="$(echo $line | cut -d, -f 10)"
    volume="$(echo $line | cut -d, -f 11)"
    marketCap="$(echo $line | cut -d, -f 12)"
    sharesOutstanding="$(echo $line | cut -d, -f 13)"
    insiderOwnership="$(echo $line | cut -d, -f 14)"
    shortPercent="$(echo $line | cut -d, -f 15)"
    float="$(echo $line | cut -d, -f 16)"
    # Get headlines
    headlines="$(curl "https://api.intrinio.com/news?ticker="$symbol"" -u "506540ef71e2788714ac2bdd2255d337:1d3bce294c77797adefb8a602339ff21")"
    #headlines="$(./jq-linux64 '.[] | select(.symbol == "'$symbol'") | .headlines' "$ecalPath"headlines.json)"

    # Generate 1 year  chart
echo "vvv Getting 1yr chart data for "$symbol" vvv"
    twelveMonthsAgo="$(date -d "12 months ago" +%Y-%m-%d)"
    curl -H "Authorization: Bearer "$tradierApi"" https://api.tradier.com/v1/markets/history?symbol=$symbol"&start="$twelveMonthsAgo -H "Accept: application/json" > $symbol"-1yr.json"

    cat "$symbol"-1yr.json | ./jq-linux64 '.history.day[].date' $1 > date.txt && sed -i 's/\"//g' date.txt
    cat "$symbol"-1yr.json | ./jq-linux64 '.history.day[].open' $1 > open.txt && sed -i 's/\"//g' open.txt
    cat "$symbol"-1yr.json | ./jq-linux64 '.history.day[].high' $1 > high.txt && sed -i 's/\"//g' high.txt
    cat "$symbol"-1yr.json | ./jq-linux64 '.history.day[].low' $1 > low.txt && sed -i 's/\"//g' low.txt
    cat "$symbol"-1yr.json | ./jq-linux64 '.history.day[].close' $1 > close.txt && sed -i 's/\"//g' close.txt
    paste -d ',' date.txt open.txt high.txt low.txt close.txt > "$symbol"-1yr.csv && sed -i '1i Date,Open,High,Low,Close' "$symbol"-1yr.csv
    dataCheck=$(cat $symbol"-1yr.csv")
    if [ "$dataCheck" != "" ]; then
        oneYearNull=0
        sed -e 's/symbol/'$symbol'/g' symbol-1yr.php > $symbol"-1yr.php"
        if test -f $pub$symbol"-1yr.csv"; then rm $pub$symbol"-1yr.csv";fi
        if test -f $pub$symbol"-1yr.php"; then rm $pub$symbol"-1yr.php";fi
        cp "$symbol"-1yr.csv $pub
        mv "$symbol"-1yr.php $pub
    else
        oneYearNull=1
        rm $symbol"-1yr.csv"
    fi
    # Clean up
    rm date.txt && rm open.txt && rm high.txt && rm low.txt && rm close.txt && rm $symbol"-1yr.json"
    # Generate 6 month chart
    sixMonthsAgo="$(date -d "6 months ago" +%Y-%m-%d)"
    tail -130 "$symbol"-1yr.csv > "$symbol"-6mo.csv && sed -i '1i Date,Open,High,Low,Close' "$symbol"-6mo.csv
    dataCheck=$(cat $symbol"-6mo.csv")
    if [ "$dataCheck" != "" ]; then
        sixMonthNull=0
        sed -e 's/symbol/'$symbol'/g' symbol-6mo.php > $symbol"-6mo.php"
        if test -f $pub$symbol"-6mo.csv"; then rm $pub$symbol"-6mo.csv";fi
        if test -f $pub$symbol"-6mo.php"; then rm $pub$symbol"-6mo.php";fi
        mv "$symbol"-6mo.csv $pub
        mv "$symbol"-6mo.php $pub
    else
        sixMonthNull=1
        rm $symbol"-6mo.csv"
    fi

    # Generate 3 month chart
    threeMonthsAgo="$(date -d "3 months ago" +%Y-%m-%d)"
    tail -65 "$symbol"-1yr.csv > "$symbol"-3mo.csv && sed -i '1i Date,Open,High,Low,Close' "$symbol"-3mo.csv
    dataCheck=$(cat $symbol"-3mo.csv")
    if [ "$dataCheck" != "" ]; then
        threeMonthNull=0
        sed -e 's/symbol/'$symbol'/g' symbol-3mo.php > $symbol"-3mo.php"
        if test -f $pub$symbol"-3mo.csv"; then rm $pub$symbol"-3mo.csv";fi
        if test -f $pub$symbol"-3mo.php"; then rm $pub$symbol"-3mo.php";fi
        mv "$symbol"-3mo.csv $pub
        mv "$symbol"-3mo.php $pub
    else
        threeMonthNull=1
        rm $symbol"-3mo.csv"
    fi

    # Generate 1 day chart
echo "vvv Getting 1d chart data for "$symbol" vvv"
    curl -H "Authorization: Bearer "$tradierApi"" -H "Accept: application/json" "https://api.tradier.com/v1/markets/timesales?symbol="$symbol"&interval=5min" > $symbol"-1d.json"
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].time' $1 | sed -e 's/\"//g' $1 | cut -dT -f 2 > date.txt
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].open' $1 | sed -e 's/\"//g' $1 > open.txt
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].high' $1 | sed -e 's/\"//g' $1 > high.txt
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].low' $1 | sed -e 's/\"//g' $1 > low.txt
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].close' $1 | sed -e 's/\"//g' $1 > close.txt
    paste -d ',' date.txt open.txt high.txt low.txt close.txt > "$symbol"-1d.csv && sed -i '1i Date,Open,High,Low,Close' "$symbol"-1d.csv
    dataCheck=$(cat $symbol"-1d.csv")
    if [ "$dataCheck" != "" ]; then
        oneDayNull=0
        sed -e 's/symbol/'$symbol'/g' symbol-1d.php > $symbol"-1d.php"
        wc=$(wc -l "$symbol"-1d.csv | cut -d' ' -f1)
        xTicks=$(($wc -2))
        sed -i 's/xTix/'$xTicks'/g' $symbol"-1d.php"
        if test -f $pub$symbol"-1d.csv"; then rm $pub$symbol"-1d.csv";fi
        if test -f $pub$symbol"-1d.php"; then rm $pub$symbol"-1d.php";fi
        mv "$symbol"-1d.csv $pub
        mv "$symbol"-1d.php $pub
    else
        oneDayNull=1
        rm $symbol"-1mo.csv"
    fi

    # Generate 1 day chart for new app
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].timestamp' $1 | while read time; do echo '"'$time'"';done > time.txt
    cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].close' $1 | while read close; do echo '"y"':'"'$close'"'};done > close.txt
    paste -d ',' time.txt close.txt | while read line; do echo {'"x"':$line >> combined.txt; done;

    echo '[{"values":[' > $symbol"-1d-chart"
    # Combine all values into one line
    list=
    cat combined.txt | while read line
    do
        list=$list$line","
        echo $list > chartValues
    done
    sed -i '$ s/.$//' chartValues
    echo '],' >> chartValues
    cat chartValues >> $symbol"-1d-chart"
    echo '"color":"#03a9f4"}]' >> $symbol"-1d-chart"
    chart=$(cat $symbol"-1d-chart")

    # Clean up
    rm combined.txt && rm time.txt && rm date.txt && rm open.txt && rm high.txt && rm low.txt && rm close.txt && rm $symbol"-1d.json" && rm "$symbol"-1yr.csv

    # Check for nulls and replace with 0
    if [ "$price" = "" ]; then price=0; fi
    if [ "$change" = "" ]; then change=0; fi
    if [ "$changePercent" = "" ]; then changePercent=0; fi
    if [ "$open" = "" ]; then open=0; fi
    if [ "$high" = "" ]; then high=0; fi
    if [ "$low" = "" ]; then low=0; fi
    if [ "$volume" = "" ]; then volume=0; fi
    if [ "$avgVol" = "" ]; then avgVol=0; fi
    if [ "$sharesShort" = "null" ]; then sharesShort=0; fi
    if [ "$sharesShort" = "" ]; then sharesShort=0; fi
    if [ "$shortPercent" = "" ]; then shortPercent=0; fi
    if [ "$marketCap" = "" ]; then marketCap=0; fi
    if [ "$float" = "" ]; then float=0; fi

    # Build JSON
    echo '{"id":"'$id'","list":"Pre Market Movers","symbol": "'$symbol'","name": "'$name'","price": '$price',"dollarChange": '$change',"percentChange": '$changePercent',"oneDayNull":"'$oneDayNull'","oneDay": "http://automatedinvestmentresearch.com/'$symbol'-1d.php","oneMonthNull":"'$oneMonthNull'","oneMonth": "http://automatedinvestmentresearch.com/'$symbol'-1mo.php","threeMonthNull":"'$threeMonthNull'","threeMonth": "http://automatedinvestmentresearch.com/'$symbol'-3mo.php","sixMonthNull":"'$sixMonthNull'","sixMonth": "http://automatedinvestmentresearch.com/'$symbol'-6mo.php","oneYearNull":"'$oneYearNull'","oneYear": "http://automatedinvestmentresearch.com/'$symbol'-1yr.php","open": '$open',"high": '$high',"low":'$low',"volume": '$volume',"avgVol": '$avgVol',"sharesShort": '$sharesShort',"shortPercent": '$shortPercent',"marketCap": '$marketCap',"float": '$float',"headlines":'$headlines',"chart":'$chart'},' >> data.json
    # Build CSV for AIR v1 list
    echo $symbol","$sharesShort","$avgVol","$name","$price","$price","$volume","$changePercent >> gainers.csv
    # Copy symbol list for download
    printf $symbol"\n" >> symbols.txt

    id=$(($id + 1))
done
}
if test -f market.movers.csv; then finalQuotes;fi

# Remove , from json
sed -i '$ s/.$//' data.json
echo ']' >> data.json

# Check for empty data set
wc=$(wc -c symbols.txt | cut -d' ' -f1)
if [ $wc -lt 3 ]; then
    echo "[]" > $dePath"gainers-intraday-data.json"
    echo "[]" > $gainersPath"data.json"
else
    # Clean up and prepare data for other scans
    cat data.json > $gainersPath"data.json"
    cat data.json > $gainersDevPath"data.json"
    mv data.json $dePath"gainers-intraday-data.json" && mv symbols.txt $gainersPath"symbols.txt" && rm market.movers.csv && mv gainers.csv ~/gainers.csv
fi

