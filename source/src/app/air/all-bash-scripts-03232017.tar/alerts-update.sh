#!/bin/bash
pub=~/public_html/
# Generate the goods
cat alerts.symbols.triggers | while read line || [ -n "$line" ]
do
    symbol="$(echo $line | cut -d, -f 1)"
    trigger="$(echo $line | cut -d, -f 2)"
    historicalData="$(curl -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6" https://api.tradier.com/v1/markets/history?symbol="$symbol" -H "Accept: application/json")"
    data="$(curl -X GET "https://api.tradier.com/v1/markets/quotes?symbols="$symbol"" -H "Accept: application/json" -H "Authorization: Bearer 2IigxmuJp1Vzdq6nJKjxXwoXY9D6")"	
    volume="$(echo $historicalData | ./jq-linux64 '.history.day[].volume' $1)"
    volume60=$(echo $volume | tr ' ' '\n' | tail -60)
    averageVolume="$(echo $volume60 | tr ' ' '\n' | awk '{ sum += $1 } END { if (NR > 0) printf("%f", sum / NR) }')"
    company="$(echo $data | ./jq-linux64 '.quotes.quote.description' $1)"
    company="$(echo $company | sed 's/,//')"
    intradayPrice="$(echo $data | ./jq-linux64 '.quotes.quote.last' $1)"
    intradayVolume="$(echo $data | ./jq-linux64 '.quotes.quote.volume' $1)"
    percentChange="$(echo $data | ./jq-linux64 '.quotes.quote.change_percentage' $1)"
    # Get shares short
    shortData="$(curl https://www.quandl.com/api/v3/datasets/SI/"$symbol"_SI.json?api_key=pDqgMz1TxeRQxoExz8VW)"
    short="$(echo $shortData | ./jq-linux64 '.dataset.data[0][1]' $1)"
    echo $symbol","$short","$averageVolume","$company","$intradayPrice","$intradayVolume","$percentChange","$trigger >> alerts.sort.csv
done
# Sort by percent change
 sort -t , -k 7nr alerts.sort.csv > alerts.sorted.csv && rm alerts.sort.csv
# Remove double quotes
 sed 's/\"//g' alerts.sorted.csv > alerts.tmp.csv && mv alerts.tmp.csv alerts.sorted.csv
 mv alerts.sorted.csv alerts.csv
 