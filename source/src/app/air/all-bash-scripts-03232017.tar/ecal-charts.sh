#!/bin/bash
# Define variables
pub=~/public_html/

# Clean up
while read s; do
        rm public_html/"$s".csv && rm public_html/"$s".php
done <symbols
# Iterate through each symbol and pull price history
while read s; do
	wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc"	
	mv $s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc" $s".csv"
	cut --complement -d, -f 3-9,13 $s".csv" > $s"-3mo.csv" && rm $s".csv" && mv $s"-3mo.csv" $pub$s".csv"
	sed -i 1d  $pub$s".csv"
	sed -i '1i Date,Open,High,Low,Close' $pub$s".csv"
done <symbols
        
# Iterate through each symbol and build php file
while read s; do
	sed 's/symbol/'$s'/g' $pub"symbol.php" > $pub$s".php"
done <symbols