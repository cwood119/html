#!/bin/bash

# Define Variables
tomorrow=$(date --date="next day" "+%Y%m%d")
today=`date +%Y-%m-%d`
pub=~/public_html/QuoVadimus/

# Get Nightly Calendar and format
wget https://www.quandl.com/api/v3/databases/ZEA/download?api_key=pDqgMz1TxeRQxoExz8VW
mv download?api_key=pDqgMz1TxeRQxoExz8VW ZEA.zip && unzip ZEA.zip && mv ZEA-1.csv $pub && rm ZEA.zip
cut --complement -d, -f 2,3-5,7-10,12-15 $pub"ZEA-1.csv" > $pub"ZEA-cut.csv"
awk "/$tomorrow/" $pub"ZEA-cut.csv" > $pub"tomorrow.csv"
sed -i 1d $pub"tomorrow.csv"
sort -t, -k 1,1 $pub"tomorrow.csv" > $pub"tomorrow-sorted.csv" && rm $pub"tomorrow.csv"

# Get EOD Price and format
wget "https://www.quandl.com/api/v3/databases/EOD/data?api_key=pDqgMz1TxeRQxoExz8VW&download_type=partial"
mv "data?api_key=pDqgMz1TxeRQxoExz8VW&download_type=partial" EOD.zip && unzip EOD.zip && mv EOD*.partial.csv $pub"EOD.csv" && rm EOD.zip
if test -f $pub"EOD-cut.csv"; then rm $pub"EOD-cut.csv";fi
cut --complement -d, -f 2-5,7-14 $pub"EOD.csv" > $pub"EOD-cut.csv" && rm $pub"EOD.csv"

# Combine calendar and price data
sort -t , -k 1,1 $pub"EOD-cut.csv" > $pub"EOD-sorted.csv" && cp $pub"EOD-sorted.csv" EOD.csv
join -t , -1 1 -2 1 $pub"EOD-sorted.csv" $pub"tomorrow-sorted.csv" > $pub"joined.csv"

# Filter by price
sed -i '1i Symbol,Price,Date,Time' $pub"joined.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Price"] < 20' $pub"joined.csv" > $pub"filterOne.csv"
sed -i '1i Symbol,Price,Date,Time' $pub"filterOne.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Price"] > 1' $pub"filterOne.csv" > $pub"filterPrice.csv"

# Get company name
wget http://www.quandl.com/api/v3/databases/EOD/codes
mv codes codes.zip && unzip codes.zip
cut -c5- EOD-datasets-codes.csv > removeEOD.csv
sed 's/\"//g' removeEOD.csv > removeQuotes.csv
sed 's/(.*//' removeQuotes.csv > $pub"names.csv"

# Clean up names data and combine with price
sort -t , -k 1,1 $pub"names.csv" > $pub"names-sorted.csv" && rm $pub"names.csv"
sed 's/ $//' $pub"names-sorted.csv" > $pub"names.csv" && rm $pub"names-sorted.csv"
join -t , -1 1 -2 1 $pub"names.csv" $pub"filterPrice.csv" > $pub"combined.csv"

# Get average volume
cut --complement -d, -f 2-5 $pub"combined.csv" > symbols
while read s; do
        wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?rows=90&order=desc&column_index=5&api_key=pDqgMz1TxeRQxoExz8VW"
        mv $s".csv?rows=90&order=desc&column_index=5&api_key=pDqgMz1TxeRQxoExz8VW" $s
        cut --complement -d, -f 1 $s > $s"vol" && rm $s && mv $s"vol" $s
        while read; do
                avg=$(awk '{ sum += $1 } END { if (NR > 0) printf("%f", sum / NR) }')
        done <$s
        echo $s","$avg >>  $pub"adv.csv"
	rm $s
done <symbols

# Combine average volume with the rest of the data
join -t , -1 1 -2 1 $pub"adv.csv" $pub"combined.csv" > $pub"volCombined.csv"

# Get shares short
cut --complement -d, -f 2-6 $pub"volCombined.csv" > symbols
while read s; do
        wget "https://www.quandl.com/api/v1/datasets/SI/"$s"_SI.csv?api_key=pDqgMz1TxeRQxoExz8VW"
        mv $s"_SI.csv?api_key=pDqgMz1TxeRQxoExz8VW" $s
        cut --complement -d, -f 1,3,4 $s > $s"short" && rm $s && mv $s"short" $s
        sed -i 1d $s
        short=$(head -1 $s)     
        echo $s","$short >>  $pub"short.csv"
	rm $s
	if test -f $s"short"; then rm $s"short";fi
done <symbols

# Combine shares short with the rest of the data into tomorrow.csv
rm tomorrow.csv
join -t , -1 1 -2 1 $pub"short.csv" $pub"volCombined.csv" > ~/tomorrow.csv

# Export to running csv
cat ~/tomorrow.csv >> ~/tomorrow-db.csv

# Clean up
rm codes.zip && rm EOD-datasets-codes.csv && rm removeEOD.csv && rm removeQuotes.csv && rm $pub"EOD-cut.csv" && rm $pub"EOD-sorted.csv" && rm $pub"joined.csv" && rm $pub"tomorrow-sorted.csv" && rm $pub"ZEA-1.csv" && rm $pub"ZEA-cut.csv" && rm $pub"filterOne.csv" && rm $pub"names.csv" && rm $pub"filterPrice.csv" && rm $pub"adv.csv" && rm $pub"combined.csv" && rm $pub"volCombined.csv" && rm $pub"short.csv"

# Generate charts
pub=~/public_html/
# Iterate through each symbol and pull price history
while read s; do
	wget "https://www.quandl.com/api/v3/datasets/EOD/"$s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc"	
	mv $s".csv?api_key=pDqgMz1TxeRQxoExz8VW&rows=62&order=desc" $s".csv"
	cut --complement -d, -f 3-9,13 $s".csv" > $s"-3mo.csv" && rm $s".csv" && mv $s"-3mo.csv" $pub$s".csv"
	sed -i 1d  $pub$s".csv"
	sed -i '1i Date,Open,High,Low,Close' $pub$s".csv"
done <symbols
        
# Iterate through each symbol and build php file
while read s; do
	sed 's/symbol/'$s'/g' $pub"symbol.php" > $pub$s".php"
done <symbols

# Copy for preview
head -6 tomorrow.csv > tomorrow-preview.csv