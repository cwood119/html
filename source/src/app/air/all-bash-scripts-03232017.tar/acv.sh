#!/bin/bash
# This script will generate the html files for the Air Chart Vault (acv)
# Define variables
charts=~/public_html/wp-content/plugins/s2member-files/access-s2member-level1/Charts/
files=~/public_html/wp-content/plugins/s2member-files/access-s2member-level1/AIR-Chart-Vault/
url='http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/'
header='AIR Chart Vault'

category1='Day 1 Breakouts'
description1='Breakouts that occur on the initial day of the earnings reaction tend to offer the most volatility in the shortest period of time, making it essential to enter trades with a set risk and a solid plan. Consider buying earnings winners on day 1 as they breakout above intraday or prior points of resistance.'
file1=$files'day1-breakouts.html'
dir1='Day_1/Breakouts/'

category2='Day 2 Breakouts'
description2='Description for day 2 breakouts'
file2=$files'day2-breakouts.html'
dir2='Day_2/Breakouts/'

category3='Day 3-10 Breakouts'
description3='Description for day 3-10 breakouts'
file3=$files'day3-breakouts.html'
dir3='Days_3_10/Breakouts/'

category4='PEAD'
description4='Description for the post earnings announcement drift'
file4=$files'pead.html'
dir4='PEAD/'

category5='Channels'
description5='Although many swing traders focus on anticipating the breakout after a period of consolidation, channel trading is arguably one of the simplest swing strategies to implement. When a stock trades within a defined price channel, whether bullish, bearish or trendless, the consistent oscillation of price between support and resistance levels offers multiple opportunities within a relatively short period.'
file5=$files'channels.html'
dir5='Channels/'

# Replace any spaces in file names with -
find $path -depth -name "* *" -execdir rename 's/ /_/g' "{}" \;

# Copy first part of html template
head -31 acvTemplate.html | tee $file1 $file2 $file3 $file4 $file5  >/dev/null

# Insert category heading and text
# Category 1
echo '<h1>'$header'<br /><span class="light"><span class="grey"><span class="s36">'$category1'</span></span></span></h1><p>'$description1'</p><div id="toolbar"></div><div class="clear"></div>' >> $file1
# Get all files in Category 1 directory 
ls $charts$dir1 > files.txt
# Build the thumbnail html
cat files.txt | while read line || [ -n "$line" ]
do
    echo '<a href="'$url$dir1$line'" class="thumb_link"><span class="selected"></span><img width="145px" height="90px" src="'$url$dir1$line'" title="'$line'" alt="'$line'" class="thumb"></a>' >> $file1
done

# Category 2
echo '<h1>'$header'<br /><span class="light"><span class="grey"><span class="s36">'$category2'</span></span></span></h1><p>'$description2'</p><div id="toolbar"></div><div class="clear"></div>' >> $file2
# Get all files in Category 2 directory 
ls $charts$dir2 > files.txt
# Build the thumbnail html
cat files.txt | while read line || [ -n "$line" ]
do
    echo '<a href="'$url$dir2$line'" class="thumb_link"><span class="selected"></span><img width="145px" height="90px" src="'$url$dir2$line'" title="'$line'" alt="'$line'" class="thumb"></a>' >> $file2
done

# Category 3
echo '<h1>'$header'<br /><span class="light"><span class="grey"><span class="s36">'$category3'</span></span></span></h1><p>'$description3'</p><div id="toolbar"></div><div class="clear"></div>' >> $file3
# Get all files in Category 3 directory 
ls $charts$dir3 > files.txt
# Build the thumbnail html
cat files.txt | while read line || [ -n "$line" ]
do
    echo '<a href="'$url$dir3$line'" class="thumb_link"><span class="selected"></span><img width="145px" height="90px" src="'$url$dir3$line'" title="'$line'" alt="'$line'" class="thumb"></a>' >> $file3
done

# Category 4
echo '<h1>'$header'<br /><span class="light"><span class="grey"><span class="s36">'$category4'</span></span></span></h1><p>'$description4'</p><div id="toolbar"></div><div class="clear"></div>' >> $file4
# Get all files in Category 4 directory 
ls $charts$dir4 > files.txt
# Build the thumbnail html
cat files.txt | while read line || [ -n "$line" ]
do
    echo '<a href="'$url$dir4$line'" class="thumb_link"><span class="selected"></span><img width="145px" height="90px" src="'$url$dir4$line'" title="'$line'" alt="'$line'" class="thumb"></a>' >> $file4
done

# Category 5
echo '<h1>'$header'<br /><span class="light"><span class="grey"><span class="s36">'$category5'</span></span></span></h1><p>'$description5'</p><div id="toolbar"></div><div class="clear"></div>' >> $file5
# Get all files in Category 5 directory 
ls $charts$dir5 > files.txt
# Build the thumbnail html
cat files.txt | while read line || [ -n "$line" ]
do
    echo '<a href="'$url$dir5$line'" class="thumb_link"><span class="selected"></span><img width="145px" height="90px" src="'$url$dir5$line'" title="'$line'" alt="'$line'" class="thumb"></a>' >> $file5
done

# Copy last part of html template
tail -247 acvTemplate.html | tee -a $file1 $file2 $file3 $file4 $file5  >/dev/null

# Clean up
rm files.txt

# Legacy code for charts if you want to use the list template
# Generate image html from directory contents
#ls $(find $path"/Day_1/Breakouts/" -type f ) > tmp.csv && awk '{print $0",1,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Breakouts/"$0}' tmp.csv > deCharts.csv
#ls $(find $path"/Day_1/Dip/" -type f ) > tmp.csv && awk '{print $0",1,2,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Dip/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Day_1/Morning_Spike/" -type f ) > tmp.csv && awk '{print $0",1,3,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Morning_Spike/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Day_2/Breakouts/" -type f ) > tmp.csv && awk '{print $0",2,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_2/Breakouts/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Day_2/Dips/" -type f ) > tmp.csv && awk '{print $0",2,2,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/Dips/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Day_2/Red_to_Green/" -type f ) > tmp.csv && awk '{print $0",2,3,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Day_1/red_to_green/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Days_3_10/Breakouts/" -type f ) > tmp.csv && awk '{print $0",3,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Days_3_10/Breakouts/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Days_3_10/Dips/" -type f ) > tmp.csv && awk '{print $0",3,2,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Days_3_10/Dips/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/PEAD/" -type f ) > tmp.csv && awk '{print $0",4,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/PEAD/"$0}' tmp.csv >> deCharts.csv
#ls $(find $path"/Channels/" -type f ) > tmp.csv && awk '{print $0",5,1,http://automatedinvestmentresearch.com/wp-content/plugins/s2member-files/access-s2member-level1/Charts/Channels/"$0}' tmp.csv >> deCharts.csv
#rm tmp.csv