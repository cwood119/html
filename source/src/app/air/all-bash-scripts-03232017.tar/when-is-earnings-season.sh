#!/bin/bash

# Define Variables
pub=~/public_html/QuoVadimus/
thisMonth=$(date +%m)
thisYear=$(date +%Y)
nextMonth=$(date --date="$(date +%Y-%m-15) +1 month" +'%m')
twoMonths=$(date --date="$(date +%Y-%m-15) +2 month" +'%m')
count=0

# Get Calendar and format
wget https://www.quandl.com/api/v3/databases/ZEA/download?api_key=pDqgMz1TxeRQxoExz8VW
mv download?api_key=pDqgMz1TxeRQxoExz8VW ZEA.zip && unzip ZEA.zip && mv ZEA-1.csv $pub && rm ZEA.zip
cut --complement -d, -f 2,3-5,7-10,12-15 $pub"ZEA-1.csv" > $pub"ZEA-cut.csv"
#awk "/$tomorrow/" $pub"ZEA-cut.csv" > $pub"dates.csv"
cat $pub"ZEA-cut.csv" | egrep -v '_' > $pub"dates.csv"
sed -i 1d $pub"dates.csv"
sort -t, -k 1,1 $pub"dates.csv" > $pub"dates-sorted.csv" && rm $pub"dates.csv"

# Get EOD Price and format
wget "https://www.quandl.com/api/v3/databases/EOD/data?api_key=pDqgMz1TxeRQxoExz8VW&download_type=partial"
mv "data?api_key=pDqgMz1TxeRQxoExz8VW&download_type=partial" EOD.zip && unzip EOD.zip && mv EOD*.partial.csv $pub"EOD.csv" && rm EOD.zip
if test -f $pub"EOD-cut.csv"; then rm $pub"EOD-cut.csv";fi
cut --complement -d, -f 2-5,7-14 $pub"EOD.csv" > $pub"EOD-cut.csv" && rm $pub"EOD.csv"

# Combine calendar and price data
sort -t , -k 1,1 $pub"EOD-cut.csv" > $pub"EOD-sorted.csv"
join -t , -1 1 -2 1 $pub"EOD-sorted.csv" $pub"dates-sorted.csv" > $pub"joined.csv"

# Filter by price
sed -i '1i Symbol,Price,Date,Time' $pub"joined.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Price"] < 20' $pub"joined.csv" > $pub"filterOne.csv"
sed -i '1i Symbol,Price,Date,Time' $pub"filterOne.csv"
awk -F, 'NR == 1 { for(i = 1; i <= NF; ++i) { col[$i] = i }; next } $col["Price"] > 1' $pub"filterOne.csv" > $pub"filterPrice.csv"

# Get company name
wget http://www.quandl.com/api/v3/databases/EOD/codes
mv codes codes.zip && unzip codes.zip
cut -c5- EOD-datasets-codes.csv > removeEOD.csv
sed 's/\"//g' removeEOD.csv > removeQuotes.csv
sed 's/(.*//' removeQuotes.csv > $pub"names.csv"

# Clean up names data and combine with price
sort -t , -k 1,1 $pub"names.csv" > $pub"names-sorted.csv" && rm $pub"names.csv"
sed 's/ $//' $pub"names-sorted.csv" > $pub"names.csv" && rm $pub"names-sorted.csv"
join -t , -1 1 -2 1 $pub"names.csv" $pub"filterPrice.csv" > $pub"combined.csv"

# Get dates and count the number of announcements in a given month

cut --complement -d, -f 1-3,5 $pub"combined.csv" > dates.csv
sed -i 's/..$//' dates.csv

# Get announcements for next month
#cat dates.csv | while read line
#    do
#        if [[ $line -lt $thisYear$twoMonths"00" ]] && [[ $line -gt $thisYear$nextMonth"00"  ]]; then
#            (( count++ ))
#            echo $count > count
#        fi
#    done
# Get announcements

for (( i = 1; i <= 12; ++i )) {
        next=$(( $i + 1 ))
        next=`printf "%02d" $next`
        prev=$(( $i - 1 ))
        prev=`printf "%02d" $prev`
        cat dates.csv | while read line
            do
                if [[ $line -lt $thisYear$next"00" ]] && [[ $line -gt $thisYear$prev"00"  ]]; then
                    (( count++ ))
                    month=`printf "%02d" $i`
                    MONTHS=(ZERO Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec)
                    echo ${MONTHS[$i]}","$count > $month".csv"

                fi
            done
}
cat $thisMonth".csv" > announcements.csv && cat $nextMonth".csv" >> announcements.csv && cat $twoMonths".csv" >> announcements.csv
sed -i '1i Month,Announcements' announcements.csv
# Clean up
rm EOD-datasets-codes.csv && rm removeEOD.csv && rm removeQuotes.csv && rm codes.zip && rm ~/public_html/QuoVadimus/*.csv && rm dates.csv

mv announcements.csv $pub"announcements.csv"