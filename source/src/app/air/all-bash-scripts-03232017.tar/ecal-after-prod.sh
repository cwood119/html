#!/bin/bash
# After-market earnings calendar scanner

# Define Variables
pub=~/public_html/
ecalPath=~/public_html/app/app/air/earnings-calendar/data/
ecalDevPath=~/public_html/dev/app/air/earnings-calendar/data/
dePath=~/public_html/app/app/air/decision-engine/data/
tradierApi=2IigxmuJp1Vzdq6nJKjxXwoXY9D6
yesterday=$(date --date="yesterday" "+%m/%d/%Y")
regularHoursClose=15:55
afterHoursClose=20:00
afterHoursEpoch=$(date -d "$yesterday $afterHoursClose" +%s)
regularHoursEpoch=$(date -d "$yesterday $regularHoursClose" +%s)

# Iterate through symbols and request after market price.
# Remove after.csv for v1 AIR list
rm after.csv
echo '[' > data.json
touch symbols.txt
id=1
cat $ecalPath"ecal-update-symbols" | while read line || [ -n "$line" ]
do
    # Define variables for symbol card and vitals
    symbol="$(echo $line | cut -d, -f 1)"
    sharesShort="$(echo $line | cut -d, -f 2)"
    avgVol="$(echo $line | cut -d, -f 3)"
    name="$(echo $line | cut -d, -f 4)"
    #name="$(echo $name | cut -c1-20)"
    price="$(echo $line | cut -d, -f 5)"
    time="$(echo $line | cut -d, -f 6)"
    #change="$(echo $line | cut -d, -f 7)"
    #changePercent="$(echo $line | cut -d, -f 8)"
    open="$(echo $line | cut -d, -f 9)"
    high="$(echo $line | cut -d, -f 10)"
    low="$(echo $line | cut -d, -f 11)"
    volume="$(echo $line | cut -d, -f 12)"
    marketCap="$(echo $line | cut -d, -f 13)"
    sharesOutstanding="$(echo $line | cut -d, -f 14)"
    insiderOwnership="$(echo $line | cut -d, -f 15)"
    shortPercent="$(echo $line | cut -d, -f 16)"
    float="$(echo $line | cut -d, -f 17)"
 
    # Get time and sales data
    curl -H "Authorization: Bearer "$tradierApi"" -H "Accept: application/json" "https://api.tradier.com/v1/markets/timesales?symbol="$symbol"&interval=5min" > $symbol"-1d.json"
    # Get the latest price 
    afterPrice=$(./jq-linux64 '.series.data[-1].price' $symbol"-1d.json")    
    afterTimestamp=$(./jq-linux64 '.series.data[-1].timestamp' $symbol"-1d.json")
    # If the last tick price was later (in epoch time) than the close of regular hours, it's a after-market tick.
    if [[ $afterTimestamp -gt $regularHoursEpoch ]] ; then
        if (( $(echo "$afterPrice > $price" | bc -l) )) ; then
            # Calculate percent change
            change=$(echo $afterPrice - $price | bc | awk '{printf "%f", $0}')
            percentCalc=$(echo $change / $price | bc -l)
            changePercent=$(echo $percentCalc \* 100 | bc -l | awk '{printf "%f", $0}') 
            # Get headlines
            headlines="$(curl "https://api.intrinio.com/news?ticker="$symbol"" -u "506540ef71e2788714ac2bdd2255d337:1d3bce294c77797adefb8a602339ff21")"

            # Check for nulls and replace with 0
            if [ "$afterPrice" = "" ]; then afterPrice=0; fi
            if [ "$change" = "" ]; then change=0; fi
            if [ "$changePercent" = "" ]; then changePercent=0; fi
            if [ "$time" = "" ]; then time=0; fi
            if [ "$open" = "" ]; then open=0; fi
            if [ "$high" = "" ]; then high=0; fi
            if [ "$low" = "" ]; then low=0; fi
            if [ "$volume" = "" ]; then volume=0; fi
            if [ "$avgVol" = "" ]; then avgVol=0; fi
            if [ "$sharesShort" = "" ]; then sharesShort=0; fi
            if [ "$sharesShort" = "null" ]; then sharesShort=0; fi
            if [ "$shortPercent" = "" ]; then shortPercent=0; fi
            if [ "$marketCap" = "" ]; then marketCap=0; fi
            if [ "$float" = "" ]; then float=0; fi

            # Generate 1 day chart for new app
            cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].timestamp' $1 | while read time; do echo '"'$time'"';done > time.txt
            cat "$symbol"-1d.json | ./jq-linux64 '.series.data[].close' $1 | while read close; do echo '"y"':'"'$close'"'};done > close.txt
            paste -d ',' time.txt close.txt | while read line; do echo {'"x"':$line >> combined.txt; done;

            echo '[{"values":[' > $symbol"-1d-chart"
            # Combine all values into one line
            list=
            cat combined.txt | while read line
            do
                list=$list$line","
                echo $list > chartValues
            done
            sed -i '$ s/.$//' chartValues
            echo '],' >> chartValues
            cat chartValues >> $symbol"-1d-chart"
            echo '"color":"#03a9f4"}]' >> $symbol"-1d-chart"
            chart=$(cat $symbol"-1d-chart")

            # Clean up
            rm chartValues && rm combined.txt && rm time.txt && rm date.txt && rm $symbol"-1d.json"

            oneDayNull=$(./jq-linux64 '.[] | select(.symbol == "'$symbol'") | .oneDayNull' $dePath"ecal-intraday-data.json")
            threeMonthNull=$(./jq-linux64 '.[] | select(.symbol == "'$symbol'") | .threeMonthNull' $dePath"ecal-intraday-data.json")
            sixMonthNull=$(./jq-linux64 '.[] | select(.symbol == "'$symbol'") | .sixMonthNull' $dePath"ecal-intraday-data.json")
            oneYearNull=$(./jq-linux64 '.[] | select(.symbol == "'$symbol'") | .oneYearNull' $dePath"ecal-intraday-data.json")
            
            if [ "$oneDayNull" = "" ]; then oneDayNull=1; fi
            if [ "$threeMonthNull" = "" ]; then threeMonthNull=1; fi
            if [ "$sixMonthNull" = "" ]; then sixMonthNull=1; fi
            if [ "$oneYearNull" = "" ]; then oneYearNull=1; fi
            
            # Build JSON
            echo '{"id":"'$id'","list":"After Market Movers","nullFlag":"","symbol": "'$symbol'","name": "'$name'","price": '$afterPrice',"dollarChange": '$change',"percentChange": '$changePercent',"time":'$time',"oneDayNull":'$oneDayNull',"oneDay": "http://automatedinvestmentresearch.com/'$symbol'-1d.php","oneMonth": "http://automatedinvestmentresearch.com/'$symbol'-1mo.php","threeMonthNull":'$threeMonthNull',"threeMonth": "http://automatedinvestmentresearch.com/'$symbol'-3mo.php","sixMonthNull":'$sixMonthNull',"sixMonth": "http://automatedinvestmentresearch.com/'$symbol'-6mo.php","oneYearNull":'$oneYearNull',"oneYear": "http://automatedinvestmentresearch.com/'$symbol'-1yr.php","open": '$open',"high": '$high',"low":'$low',"volume": '$volume',"avgVol": '$avgVol',"sharesShort": '$sharesShort',"shortPercent": '$shortPercent',"marketCap": '$marketCap',"float": '$float',"headlines":'$headlines', "chart":'$chart'},' >> data.json
            # Build CSV for AIR v1 list
            echo $symbol","$sharesShort","$avgVol","$name","$afterPrice", ,"$time","$afterPrice","$changePercent >> after.csv
            # Copy symbol list for download
            printf $symbol"\n" >> symbols.txt
            id=$(($id + 1))
        fi
    fi
done
# Remove , from json
sed -i '$ s/.$//' data.json
echo ']' >> data.json

# Check for empty data set
wc=$(wc -l data.json | cut -d' ' -f1)
if [ $wc -lt 3 ]; then
    rm data.json
    rm symbols.txt
else
    # Clean up and prepare data for other scans
    cat data.json > $ecalPath"data.json"
    cat data.json > $ecalDevPath"data.json"
    mv data.json $dePath"ecal-after-data.json"
    mv symbols.txt $ecalPath"symbols.txt"
fi
